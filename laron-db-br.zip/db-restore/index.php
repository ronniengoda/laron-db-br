<?php 
define("PREPEND_PATH", "../../");
$hooks_dir = dirname(__FILE__);
include("../../defaultLang.php");
include("../../language.php");
include("../../lib.php");
include_once("../../header.php");
include '../../config.php';
?>
<!DOCTYPE html>
<html>
<head>
	<title>DB RESTORE</title>
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="panel panel-primary">
				<div class="panel-heading"><strong>SELECT THE DATABASE BACKUP FILE YOU WANT TO RESTORE</strong></div>
				<div class="panel-body">
					<form action="myphp-restore.php" method="POST">
						<div class="form-group">
							<label for="backup">Select Backup File Below:</label>
							<select class="form-control" id="backup" name="backup">
								<?php
								if ($handle = opendir('myphp-backup-files')) {

									while (false !== ($entry = readdir($handle))) {

										if ($entry != "." && $entry != "..") {

											echo "<option value='$entry'>$entry</option>";
										}
									}

									closedir($handle);
								}?>
							</select><br>
							<div class="text-center"><button type="submit" class="btn btn-success"><strong>START RESTORE</strong></button></div>
						</div>
					</form>
				</div>
			</div>
		</div>
	</div>
</body>
</html>
